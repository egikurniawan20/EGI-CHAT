# EGI CHAT - Android APK via GitHub

Project ini membungkus file HTML EGI CHAT ke dalam aplikasi Android WebView.
File HTML asli berada di `app/src/main/assets/index.html`.

## Cara membuat APK dari GitHub (pakai HP)

1. Ekstrak ZIP ini.
2. Buat repository baru di GitHub, misalnya `egi-chat-android`.
3. Upload **isi folder** project ini ke repository (bukan ZIP-nya).
4. Pastikan file `.github/workflows/build-apk.yml` ikut ter-upload.
5. Buka tab **Actions** pada repository.
6. Pilih **Build EGI CHAT APK**, lalu tekan **Run workflow** jika belum berjalan otomatis.
7. Tunggu sampai proses selesai dengan tanda centang hijau.
8. Buka hasil workflow, cari bagian **Artifacts**, lalu unduh `EGI-CHAT-APK`.
9. Ekstrak hasil unduhan dan pasang `app-debug.apk` di Android. Jika diminta, izinkan instalasi dari sumber tersebut.

## Catatan penting

- APK ini adalah build debug untuk uji coba/pribadi. Untuk distribusi resmi di Play Store,
  diperlukan signing release dan pengaturan identitas aplikasi.
- HTML tetap memakai layanan Supabase dan sumber daya eksternal yang sudah ada di file.
  APK tidak mengubah atau memperbaiki konfigurasi database, tabel, kebijakan RLS, maupun akun backend.
- Izin kamera/mikrofon diminta oleh Android ketika fitur tersebut digunakan.
- Notifikasi latar belakang/push tidak otomatis dijamin oleh pembungkus WebView ini;
  memerlukan integrasi notifikasi native/push tersendiri.
- Koneksi internet diperlukan untuk layanan online dan aset eksternal.
